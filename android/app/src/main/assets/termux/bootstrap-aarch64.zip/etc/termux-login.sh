##
## This script is sourced by /data/data/com.guncat.work/abcd/bin/login before executing shell.
##
