if [ ! -f /data/data/com.guncat.work/abcde/.config/termux/termux.properties ] && [ ! -e /data/data/com.guncat.work/abcde/.termux/termux.properties ]; then
	mkdir -p /data/data/com.guncat.work/abcde/.termux
	cp /data/data/com.guncat.work/abcd/share/examples/termux/termux.properties /data/data/com.guncat.work/abcde/.termux/
fi
